import React from 'react';
import clsx from 'clsx';

const FormInput = ({
  label,
  id,
  error,
  className,
  ...props
}) => {
  return (
    <div className="mb-1">
      <label htmlFor={id} className="block text-sm font-medium text-gray-700 mb-1">
        {label}
      </label>
      <input
        id={id}
        className={clsx(
          "w-full border rounded-md px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-shadow",
          error ? "border-red-300 bg-red-50" : "border-gray-300",
          className
        )}
        {...props}
      />
      {error && (
        <p className="mt-1 text-sm text-red-600">{error}</p>
      )}
    </div>
  );
};

export default FormInput;
