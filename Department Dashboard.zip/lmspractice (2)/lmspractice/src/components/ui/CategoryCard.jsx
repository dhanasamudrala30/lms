import React from 'react';
import { PlusCircle } from 'lucide-react';
import clsx from 'clsx';

const CategoryCard = ({
  title,
  icon,
  items,
  onRemove,
  onAdd,
  actionText,
  isActive
}) => {
  return (
    <div className={clsx(
      "border rounded-lg overflow-hidden transition-all duration-300",
      isActive ? "ring-2 ring-blue-500 border-blue-300" : "border-gray-200"
    )}>
      <div className="flex items-center justify-between p-3 bg-gray-50 border-b border-gray-200">
        <div className="flex items-center">
          <div className="text-blue-600 mr-2">
            {icon}
          </div>
          <h3 className="font-medium text-gray-800">{title}</h3>
        </div>
        <button
          onClick={onAdd}
          className="text-blue-600 hover:text-blue-800 transition-colors"
        >
          <PlusCircle className="h-5 w-5" />
        </button>
      </div>
      
      <div className="bg-white p-3 max-h-48 overflow-y-auto">
        {items.length === 0 ? (
          <p className="text-gray-500 text-sm italic text-center py-2">No {title.toLowerCase()} added</p>
        ) : (
          <ul className="space-y-2">
            {items.map((item, index) => (
              <li key={index} className="flex justify-between items-center p-2 bg-gray-50 rounded">
                <span className="text-sm">{item}</span>
                <button
                  onClick={() => onRemove(index)}
                  className="text-xs px-2 py-1 bg-gray-200 hover:bg-gray-300 rounded text-gray-700 transition-colors"
                >
                  {actionText}
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
};

export default CategoryCard;
