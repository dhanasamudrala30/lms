import React, { useState, useRef } from 'react';
import { Camera } from 'lucide-react';
import { useOrganization } from '../contexts/OrganizationContext';
import FormInput from './ui/FormInput';

const OrganizationForm = () => {
  const { organization, updateOrganization } = useOrganization();
  const [avatarPreview, setAvatarPreview] = useState(organization.avatarUrl || null);
  const fileInputRef = useRef(null);

  const handleNameChange = (e) => {
    updateOrganization({ name: e.target.value });
  };

  const handleCodeChange = (e) => {
    updateOrganization({ code: e.target.value });
  };

  const handleAvatarClick = () => {
    fileInputRef.current.click(); // Triggers the hidden file input
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      const imageUrl = URL.createObjectURL(file);
      setAvatarPreview(imageUrl);
      updateOrganization({ avatarUrl: imageUrl });
    }
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-sm">
      <h2 className="text-xl font-semibold text-gray-800 mb-6">Organization Information</h2>

      <div className="flex flex-col md:flex-row gap-6">
        <div className="flex items-start">
          <div
            onClick={handleAvatarClick}
            className="relative group cursor-pointer w-24 h-24 rounded-full bg-gray-100 flex items-center justify-center overflow-hidden border-2 border-gray-200 hover:border-blue-400 transition-all duration-300"
          >
            {avatarPreview ? (
              <img
                src={avatarPreview}
                alt="Organization Avatar"
                className="w-full h-full object-cover"
              />
            ) : (
              <Camera className="h-8 w-8 text-gray-400 group-hover:text-blue-500 transition-colors" />
            )}
            <div className="absolute inset-0 bg-black/30 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
              <Camera className="h-8 w-8 text-white" />
            </div>
          </div>

          {/* Hidden file input */}
          <input
            type="file"
            accept="image/*"
            ref={fileInputRef}
            onChange={handleFileChange}
            className="hidden"
          />
        </div>

        <div className="flex-1 space-y-4">
          <FormInput
            label="Organization Name"
            id="orgName"
            value={organization.name}
            onChange={handleNameChange}
            placeholder="Enter organization name"
          />

          <FormInput
            label="Organization Code"
            id="orgCode"
            value={organization.code}
            onChange={handleCodeChange}
            placeholder="Enter organization code"
          />
        </div>
      </div>
    </div>
  );
};

export default OrganizationForm;
