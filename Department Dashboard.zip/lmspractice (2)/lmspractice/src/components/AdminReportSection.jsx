import React, { useState } from 'react';
import { Send, CheckCircle, XCircle } from 'lucide-react';
import { useOrganization } from '../contexts/OrganizationContext';

const AdminReportSection = () => {
  const { sendAdminMessage } = useOrganization();
  const [message, setMessage] = useState('');
  const [status, setStatus] = useState('idle'); // 'idle' | 'sending' | 'success' | 'error'

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!message.trim()) return;
    
    try {
      setStatus('sending');
      await sendAdminMessage(message);
      setStatus('success');
      setMessage('');
      
      setTimeout(() => {
        setStatus('idle');
      }, 3000);
    } catch (error) {
      setStatus('error');
      
      setTimeout(() => {
        setStatus('idle');
      }, 3000);
    }
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-sm">
      <h2 className="text-xl font-semibold text-gray-800 mb-6">Report to Admin</h2>
      
      <form onSubmit={handleSubmit}>
        <div className="mb-4">
          <label htmlFor="adminMessage" className="block text-sm font-medium text-gray-700 mb-1">
            Write message to admin
          </label>
          <textarea
            id="adminMessage"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            rows={4}
            placeholder="Type your message here..."
            className="w-full border border-gray-300 rounded-md px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-shadow"
          />
        </div>
        
        <div className="flex justify-end">
          <button
            type="submit"
            disabled={status === 'sending'}
            className="flex items-center bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md transition-colors disabled:bg-blue-400"
          >
            {status === 'sending' ? (
              <>
                <div className="h-4 w-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                Sending...
              </>
            ) : (
              <>
                <Send className="h-4 w-4 mr-2" />
                Send
              </>
            )}
          </button>
        </div>
        
        {status === 'success' && (
          <div className="mt-4 p-3 bg-green-50 text-green-700 rounded-md flex items-center">
            <CheckCircle className="h-5 w-5 mr-2 text-green-500" />
            Message sent successfully
          </div>
        )}
        
        {status === 'error' && (
          <div className="mt-4 p-3 bg-red-50 text-red-700 rounded-md flex items-center">
            <XCircle className="h-5 w-5 mr-2 text-red-500" />
            Failed to send message. Please try again.
          </div>
        )}
      </form>
    </div>
  );
};

export default AdminReportSection;
