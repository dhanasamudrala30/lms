import React, { useState } from 'react';
import { PlusCircle, Edit, Trash2 } from 'lucide-react';
import { useOrganization } from '../contexts/OrganizationContext';
import RepresentativeForm from './RepresentativeForm';

const RepresentativeSection = () => {
  const { organization, removeRepresentative } = useOrganization();
  const [isAdding, setIsAdding] = useState(false);
  const [editingIndex, setEditingIndex] = useState(null);

  const handleAdd = () => {
    setIsAdding(true);
    setEditingIndex(null);
  };

  const handleEdit = (index) => {
    setEditingIndex(index);
    setIsAdding(false);
  };

  const handleDelete = (index) => {
    if (confirm('Are you sure you want to remove this representative?')) {
      removeRepresentative(index);
    }
  };

  const handleFormClose = () => {
    setIsAdding(false);
    setEditingIndex(null);
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-sm">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-semibold text-gray-800">Representative Information</h2>
        <button
          onClick={handleAdd}
          className="flex items-center text-blue-600 hover:text-blue-800 transition-colors"
        >
          <PlusCircle className="h-5 w-5 mr-1" />
          <span>Add</span>
        </button>
      </div>

      {(isAdding || editingIndex !== null) && (
        <RepresentativeForm
          representative={editingIndex !== null ? organization.representatives[editingIndex] : undefined}
          index={editingIndex}
          onClose={handleFormClose}
        />
      )}

      <div className="space-y-4">
        {organization.representatives.length === 0 && !isAdding && (
          <p className="text-gray-500 italic text-center py-4">No representatives added yet.</p>
        )}

        {organization.representatives.map((rep, index) => (
          <div
            key={index}
            className="border border-gray-200 rounded-lg p-4 bg-gray-50 transition-all hover:shadow-md"
          >
            <div className="flex justify-between items-start">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-2 flex-1">
                <div>
                  <p className="text-sm text-gray-500">Name</p>
                  <p className="font-medium">{rep.name}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Email</p>
                  <p className="font-medium">{rep.email}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Contact</p>
                  <p className="font-medium">{rep.contact}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Role</p>
                  <p className="font-medium">{rep.role}</p>
                </div>
              </div>
              <div className="flex gap-2 ml-4">
                <button
                  onClick={() => handleEdit(index)}
                  className="text-gray-600 hover:text-blue-600 transition-colors p-1"
                >
                  <Edit className="h-4 w-4" />
                </button>
                <button
                  onClick={() => handleDelete(index)}
                  className="text-gray-600 hover:text-red-600 transition-colors p-1"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default RepresentativeSection;
