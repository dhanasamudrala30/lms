import React, { useState, useEffect } from 'react';
import { X } from 'lucide-react';
import { useOrganization } from '../contexts/OrganizationContext';
import FormInput from './ui/FormInput';

const emptyRep = {
  name: '',
  contact: '',
  email: '',
  role: ''
};

const RepresentativeForm = ({
  representative,
  index,
  onClose
}) => {
  const { addRepresentative, updateRepresentative } = useOrganization();
  const [form, setForm] = useState(representative || emptyRep);
  const [errors, setErrors] = useState({});

  useEffect(() => {
    setForm(representative || emptyRep);
  }, [representative]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm(prev => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: undefined }));
    }
  };

  const validate = () => {
    const newErrors = {};
    if (!form.name.trim()) newErrors.name = 'Name is required';
    if (!form.email.trim()) {
      newErrors.email = 'Email is required';
    } else if (!/\S+@\S+\.\S+/.test(form.email)) {
      newErrors.email = 'Email is invalid';
    }
    if (!form.contact.trim()) newErrors.contact = 'Contact is required';
    if (!form.role.trim()) newErrors.role = 'Role is required';

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!validate()) return;

    if (index !== null) {
      updateRepresentative(index, form);
    } else {
      addRepresentative(form);
    }

    onClose();
  };

  return (
    <div className="bg-blue-50 border border-blue-100 rounded-lg p-4 mb-6 relative">
      <button
        onClick={onClose}
        className="absolute top-4 right-4 text-gray-500 hover:text-gray-700"
      >
        <X className="h-5 w-5" />
      </button>

      <h3 className="text-lg font-medium text-gray-900 mb-4">
        {index !== null ? 'Edit Representative' : 'Add Representative'}
      </h3>

      <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <FormInput
          label="Name"
          id="repName"
          name="name"
          value={form.name}
          onChange={handleChange}
          placeholder="Enter name"
          error={errors.name}
        />

        <FormInput
          label="Email"
          id="repEmail"
          name="email"
          type="email"
          value={form.email}
          onChange={handleChange}
          placeholder="Enter email"
          error={errors.email}
        />

        <FormInput
          label="Contact"
          id="repContact"
          name="contact"
          value={form.contact}
          onChange={handleChange}
          placeholder="Enter contact number"
          error={errors.contact}
        />

        <FormInput
          label="Role"
          id="repRole"
          name="role"
          value={form.role}
          onChange={handleChange}
          placeholder="Enter role"
          error={errors.role}
        />

        <div className="md:col-span-2 flex justify-end gap-3 mt-2">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50 transition-colors"
          >
            Cancel
          </button>
          <button
            type="submit"
            className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
          >
            {index !== null ? 'Update' : 'Add'} Representative
          </button>
        </div>
      </form>
    </div>
  );
};

export default RepresentativeForm;
