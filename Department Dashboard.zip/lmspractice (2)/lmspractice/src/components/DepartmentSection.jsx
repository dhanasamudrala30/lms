import React, { useState } from 'react';
import { useOrganization } from '../contexts/OrganizationContext';
import FormInput from './ui/FormInput';
import CategoryCard from './ui/CategoryCard';
import { Users, GraduationCap, FileText } from 'lucide-react';

const DepartmentSection = () => {
  const { organization, updateDepartment } = useOrganization();
  const [newItem, setNewItem] = useState('');
  const [activeCategory, setActiveCategory] = useState(null); // 'members' | 'students' | 'tests'

  const handleNameChange = (e) => {
    updateDepartment({ name: e.target.value });
  };

  const handleAddItem = () => {
    if (!newItem.trim() || !activeCategory) return;
    
    const updated = [...organization.department[activeCategory], newItem.trim()];
    updateDepartment({ [activeCategory]: updated });
    setNewItem('');
  };

  const handleRemoveItem = (category, index) => {
    const updated = organization.department[category].filter((_, i) => i !== index);
    updateDepartment({ [category]: updated });
  };

  const handleInputKeyDown = (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleAddItem();
    }
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-sm">
      <h2 className="text-xl font-semibold text-gray-800 mb-6">Department Information</h2>
      
      <div className="mb-6">
        <FormInput
          label="Department Name"
          id="deptName"
          value={organization.department.name}
          onChange={handleNameChange}
          placeholder="Enter department name"
        />
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <CategoryCard
          title="Mentors"
          icon={<Users className="h-5 w-5" />}
          items={organization.department.members}
          onRemove={(index) => handleRemoveItem('mentors', index)}
          onAdd={() => setActiveCategory('mentors')}
          actionText="Remove"
          isActive={activeCategory === 'mentors'}
        />
        
        <CategoryCard
          title="Students"
          icon={<GraduationCap className="h-5 w-5" />}
          items={organization.department.students}
          onRemove={(index) => handleRemoveItem('students', index)}
          onAdd={() => setActiveCategory('students')}
          actionText="Tutorials"
          isActive={activeCategory === 'students'}
        />
        
        <CategoryCard
          title="Tests"
          icon={<FileText className="h-5 w-5" />}
          items={organization.department.tests}
          onRemove={(index) => handleRemoveItem('tests', index)}
          onAdd={() => setActiveCategory('tests')}
          actionText="Exams"
          isActive={activeCategory === 'tests'}
        />
      </div>
      
      {activeCategory && (
        <div className="mt-6 flex items-center">
          <input
            type="text"
            value={newItem}
            onChange={(e) => setNewItem(e.target.value)}
            onKeyDown={handleInputKeyDown}
            placeholder={`Add new ${activeCategory.slice(0, -1)}`}
            className="flex-1 border border-gray-300 rounded-l-md px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          <button
            onClick={handleAddItem}
            className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-r-md transition-colors"
          >
            Add
          </button>
        </div>
      )}
    </div>
  );
};

export default DepartmentSection;
