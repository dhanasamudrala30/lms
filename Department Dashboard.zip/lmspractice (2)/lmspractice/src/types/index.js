export const exampleRepresentative = {
  name: '',
  contact: '',
  email: '',
  role: ''
};

export const exampleDepartment = {
  name: '',
  mentors : [],
  students: [],
  tests: []
};

export const exampleOrganization = {
  name: '',
  code: '',
  avatarUrl: '',
  department: exampleDepartment,
  representatives: []
};
