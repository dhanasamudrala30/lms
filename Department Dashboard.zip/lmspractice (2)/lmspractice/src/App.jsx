import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import OrganizationPage from './pages/OrganizationPage';
import { OrganizationProvider } from './contexts/OrganizationContext';

function App() {
  return (
    <Router>
      <OrganizationProvider>
        <div className="min-h-screen bg-gray-50">
          <Routes>
            <Route path="/" element={<OrganizationPage />} />
          </Routes>
        </div>
      </OrganizationProvider>
    </Router>
  );
}

export default App;
