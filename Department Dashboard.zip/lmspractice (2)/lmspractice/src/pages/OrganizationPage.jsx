import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import OrganizationForm from '../components/OrganizationForm';
import DepartmentSection from '../components/DepartmentSection';
import RepresentativeSection from '../components/RepresentativeSection';
import AdminReportSection from '../components/AdminReportSection';

const OrganizationPage = () => {
  const navigate = useNavigate();

  const handleBack = () => {
    // In a real app, this would navigate back
    // For now, we'll just log
    console.log('Back button clicked');
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-6 sm:px-6 lg:px-8">
      <button 
        onClick={handleBack}
        className="flex items-center text-blue-600 hover:text-blue-800 transition-colors mb-6 group"
      >
        <ArrowLeft className="h-5 w-5 mr-1 transition-transform group-hover:-translate-x-1" />
        <span>Back</span>
      </button>

      <div className="space-y-8">
        <OrganizationForm />
        <div className="h-px bg-gray-200 w-full" />
        <DepartmentSection />
        <div className="h-px bg-gray-200 w-full" />
        <RepresentativeSection />
        <div className="h-px bg-gray-200 w-full" />
        <AdminReportSection />
      </div>
    </div>
  );
};

export default OrganizationPage;
