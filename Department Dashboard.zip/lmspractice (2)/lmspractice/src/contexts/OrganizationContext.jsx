import React, { createContext, useContext, useState } from 'react';

const defaultOrganization = {
  name: '',
  code: '',
  avatarUrl: '',
  department: {
    name: '',
    members: [],
    students: [],
    tests: []
  },
  representatives: []
};

const OrganizationContext = createContext(undefined);

export function OrganizationProvider({ children }) {
  const [organization, setOrganization] = useState(defaultOrganization);

  const updateOrganization = (data) => {
    setOrganization(prev => ({ ...prev, ...data }));
  };

  const updateDepartment = (data) => {
    setOrganization(prev => ({
      ...prev,
      department: { ...prev.department, ...data }
    }));
  };

  const addRepresentative = (rep) => {
    setOrganization(prev => ({
      ...prev,
      representatives: [...prev.representatives, rep]
    }));
  };

  const updateRepresentative = (index, rep) => {
    setOrganization(prev => {
      const newReps = [...prev.representatives];
      newReps[index] = rep;
      return { ...prev, representatives: newReps };
    });
  };

  const removeRepresentative = (index) => {
    setOrganization(prev => ({
      ...prev,
      representatives: prev.representatives.filter((_, i) => i !== index)
    }));
  };

  const sendAdminMessage = async (message) => {
    // Simulate API call
    return new Promise((resolve) => {
      console.log('Message sent to admin:', message);
      setTimeout(resolve, 500);
    });
  };

  return (
    <OrganizationContext.Provider value={{
      organization,
      updateOrganization,
      updateDepartment,
      addRepresentative,
      updateRepresentative,
      removeRepresentative,
      sendAdminMessage
    }}>
      {children}
    </OrganizationContext.Provider>
  );
}

export function useOrganization() {
  const context = useContext(OrganizationContext);
  if (context === undefined) {
    throw new Error('useOrganization must be used within an OrganizationProvider');
  }
  return context;
}
