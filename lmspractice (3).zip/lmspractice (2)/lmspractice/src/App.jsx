
import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import PracticeArea from './pages/PracticeArea';


function App() {
  return (
    <BrowserRouter>
      <div className="min-h-screen bg-gray-100">
        <Routes>
          <Route path="/" element={<PracticeArea />} />
          {/* <Route path="/problem/:id" element={<ProblemSolver />} /> */}
        </Routes>
      </div>
    </BrowserRouter>
  );
}

export default App;

