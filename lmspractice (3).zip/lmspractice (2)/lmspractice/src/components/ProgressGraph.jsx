import React from 'react';

const ProgressGraph = ({ userProgress }) => {
  const calculatePercentage = (completed, total) => {
    return total === 0 ? 0 : Math.round((completed / total) * 100);
  };

  const createCircle = (completed, total, color, label) => {
    const percentage = calculatePercentage(completed, total);
    const radius = 30;
    const circumference = 2 * Math.PI * radius;
    const strokeDashoffset = circumference - (percentage / 100) * circumference;

    return (
      <div className="flex flex-col items-center">
        <div className="relative w-20 h-20">
          <svg className="transform -rotate-90 w-20 h-20">
            <circle
              cx="40"
              cy="40"
              r={radius}
              stroke="#e5e7eb"
              strokeWidth="6"
              fill="none"
            />
            <circle
              cx="40"
              cy="40"
              r={radius}
              stroke={color}
              strokeWidth="6"
              fill="none"
              strokeLinecap="round"
              strokeDasharray={circumference}
              strokeDashoffset={strokeDashoffset}
              className="transition-all duration-1000 ease-out"
            />
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <span className="text-sm font-bold text-gray-800">{percentage}%</span>
            <span className="text-xs text-gray-500">{completed}/{total}</span>
          </div>
        </div>
        <span className="mt-2 text-sm font-medium text-gray-600">{label}</span>
      </div>
    );
  };

  return (
    <div className="flex justify-between items-center">
      {createCircle(
        userProgress.easy.completed,
        userProgress.easy.total,
        '#22c55e',
        'Easy'
      )}
      {createCircle(
        userProgress.medium.completed,
        userProgress.medium.total,
        '#eab308',
        'Medium'
      )}
      {createCircle(
        userProgress.hard.completed,
        userProgress.hard.total,
        '#ef4444',
        'Hard'
      )}
    </div>
  );
};

export default ProgressGraph;
