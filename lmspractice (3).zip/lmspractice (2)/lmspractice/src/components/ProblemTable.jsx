import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Check } from 'lucide-react';

const ProblemTable = ({ problems, selectedDifficulty }) => {
  const navigate = useNavigate();
  const [sortField, setSortField] = useState('id');
  const [sortDirection, setSortDirection] = useState('asc');

  const handleSort = (field) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const sortedProblems = [...problems].sort((a, b) => {
    const aValue = a[sortField];
    const bValue = b[sortField];

    if (typeof aValue === 'string' && typeof bValue === 'string') {
      return sortDirection === 'asc'
        ? aValue.localeCompare(bValue)
        : bValue.localeCompare(aValue);
    }

    if (typeof aValue === 'number' && typeof bValue === 'number') {
      return sortDirection === 'asc' ? aValue - bValue : bValue - aValue;
    }

    return 0;
  });

  const difficultyColors = {
    Easy: 'bg-green-100 text-green-700',
    Medium: 'bg-yellow-100 text-yellow-700',
    Hard: 'bg-red-100 text-red-700',
  };

  return (
    <div className="overflow-x-auto">
      <table className="w-full">
        <thead>
          <tr className="border-b">
            <th className="px-6 py-3 text-left text-sm font-medium text-gray-500">#</th>
            <th className="px-6 py-3 text-left text-sm font-medium text-gray-500">Title</th>
            <th className="px-6 py-3 text-left text-sm font-medium text-gray-500">Difficulty</th>
            <th className="px-6 py-3 text-left text-sm font-medium text-gray-500">Category</th>
            <th className="px-6 py-3 text-left text-sm font-medium text-gray-500">Tags</th>
            <th className="px-6 py-3 text-center text-sm font-medium text-gray-500">Action</th>
          </tr>
        </thead>
        <tbody className="divide-y">
          {sortedProblems.map((problem) => (
            <tr
              key={problem.id}
              className="hover:bg-gray-50 transition-colors"
            >
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="flex items-center">
                  <span className="text-gray-900">{problem.id}</span>
                  {problem.completed && (
                    <Check className="h-4 w-4 ml-2 text-green-500" />
                  )}
                </div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <span
                  className="text-blue-600 hover:text-blue-800 cursor-pointer"
                >
                  {problem.title}
                </span>
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                  difficultyColors[problem.difficulty]
                }`}>
                  {problem.difficulty}
                </span>
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-gray-600">
                {problem.dsaCategory}
              </td>
              <td className="px-6 py-4">
                <div className="flex flex-wrap gap-1">
                  {problem.tags.map((tag) => (
                    <span
                      key={tag}
                      className="px-2 py-0.5 bg-blue-100 text-blue-600 rounded-full text-xs"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </td>
              <td className="px-6 py-4 text-center">
                <button
                  onClick={() => navigate(`/problem/${problem.id}`)}
                  className="px-4 py-1 bg-blue-600 text-white rounded-lg text-sm hover:bg-blue-700 transition-colors"
                >
                  Solve
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {sortedProblems.length === 0 && (
        <div className="text-center py-10">
          <p className="text-gray-500">No problems found for the selected filters.</p>
        </div>
      )}
    </div>
  );
};

export default ProblemTable;
