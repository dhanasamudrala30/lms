import React from 'react';

const DifficultyFilter = ({ selectedDifficulty, setSelectedDifficulty }) => {
  const difficulties = ['All', 'Easy', 'Medium', 'Hard'];

  const difficultyColors = {
    All: 'bg-blue-100 text-blue-700',
    Easy: 'bg-green-100 text-green-700',
    Medium: 'bg-yellow-100 text-yellow-700',
    Hard: 'bg-red-100 text-red-700',
  };

  const inactiveColors = {
    All: 'text-blue-600 hover:bg-blue-50',
    Easy: 'text-green-600 hover:bg-green-50',
    Medium: 'text-yellow-600 hover:bg-yellow-50',
    Hard: 'text-red-600 hover:bg-red-50',
  };

  return (
    <div className="flex flex-wrap gap-2">
      {difficulties.map((difficulty) => (
        <button
          key={difficulty}
          className={`px-4 py-1.5 rounded-full text-sm font-medium transition-colors duration-200 
            ${selectedDifficulty === difficulty 
              ? difficultyColors[difficulty] 
              : inactiveColors[difficulty]}`}
          onClick={() => setSelectedDifficulty(difficulty)}
        >
          {difficulty}
        </button>
      ))}
    </div>
  );
};

export default DifficultyFilter;
