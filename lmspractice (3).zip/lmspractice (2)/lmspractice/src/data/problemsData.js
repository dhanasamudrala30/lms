export const problems = [
  {
    id: 1,
    title: "Two Sum Problem",
    tags: ["Array", "HashMap", "Math"],
    companies: ["Google", "Amazon", "Facebook"],
    difficulty: "Easy",
    usersTried: 13456,
    acceptanceRate: "87%",
    type: "question",
    duration: "10 minutes",
    dsaCategory: "Arrays & Hashing",
    completed: true
  },
  {
    id: 2,
    title: "Palindrome Check",
    tags: ["String", "Two-Pointer", "Recursion"],
    companies: ["Microsoft", "Adobe"],
    difficulty: "Medium",
    usersTried: 8734,
    acceptanceRate: "72%",
    type: "assignment",
    duration: "20 minutes",
    dsaCategory: "Strings",
    completed: false
  },
  {
    id: 3,
    title: "Valid Parentheses",
    tags: ["Stack", "String"],
    companies: ["Amazon", "Microsoft", "Facebook"],
    difficulty: "Easy",
    usersTried: 12245,
    acceptanceRate: "81%",
    type: "question",
    duration: "15 minutes",
    dsaCategory: "Stack",
    completed: true
  },
  {
    id: 4,
    title: "Merge Two Sorted Lists",
    tags: ["LinkedList", "Recursion"],
    companies: ["Apple", "Google"],
    difficulty: "Easy",
    usersTried: 9876,
    acceptanceRate: "84%",
    type: "question",
    duration: "15 minutes",
    dsaCategory: "Linked Lists",
    completed: false
  },
  {
    id: 5,
    title: "Maximum Subarray",
    tags: ["Array", "Dynamic Programming", "Divide and Conquer"],
    companies: ["Amazon", "Microsoft"],
    difficulty: "Medium",
    usersTried: 7654,
    acceptanceRate: "68%",
    type: "assignment",
    duration: "25 minutes",
    dsaCategory: "Dynamic Programming",
    completed: true
  },
  {
    id: 6,
    title: "Binary Tree Level Order Traversal",
    tags: ["Tree", "BFS", "Binary Tree"],
    companies: ["Facebook", "Microsoft", "Amazon"],
    difficulty: "Medium",
    usersTried: 6543,
    acceptanceRate: "65%",
    type: "question",
    duration: "20 minutes",
    dsaCategory: "Trees",
    completed: false
  },
  {
    id: 7,
    title: "Number of Islands",
    tags: ["DFS", "BFS", "Union Find", "Matrix"],
    companies: ["Amazon", "Google", "Facebook"],
    difficulty: "Medium",
    usersTried: 8543,
    acceptanceRate: "59%",
    type: "assignment",
    duration: "30 minutes",
    dsaCategory: "Graphs",
    completed: false
  },
  {
    id: 8,
    title: "Reverse Linked List",
    tags: ["LinkedList", "Recursion"],
    companies: ["Apple", "Amazon", "Facebook"],
    difficulty: "Easy",
    usersTried: 11432,
    acceptanceRate: "79%",
    type: "question",
    duration: "15 minutes",
    dsaCategory: "Linked Lists",
    completed: true
  },
  {
    id: 9,
    title: "Coin Change",
    tags: ["Dynamic Programming", "BFS"],
    companies: ["Amazon", "Microsoft", "Apple"],
    difficulty: "Medium",
    usersTried: 5678,
    acceptanceRate: "53%",
    type: "assignment",
    duration: "25 minutes",
    dsaCategory: "Dynamic Programming",
    completed: false
  },
  {
    id: 10,
    title: "Merge K Sorted Lists",
    tags: ["Linked List", "Divide and Conquer", "Heap"],
    companies: ["Amazon", "Facebook", "Google"],
    difficulty: "Hard",
    usersTried: 4532,
    acceptanceRate: "47%",
    type: "assignment",
    duration: "40 minutes",
    dsaCategory: "Heap/Priority Queue",
    completed: false
  },
  {
    id: 11,
    title: "Trapping Rain Water",
    tags: ["Array", "Two Pointers", "Dynamic Programming", "Stack"],
    companies: ["Google", "Amazon", "Apple"],
    difficulty: "Hard",
    usersTried: 3789,
    acceptanceRate: "42%",
    type: "question",
    duration: "35 minutes",
    dsaCategory: "Two Pointers",
    completed: false
  },
  {
    id: 12,
    title: "Word Search II",
    tags: ["Backtracking", "Trie"],
    companies: ["Amazon", "Microsoft", "Google"],
    difficulty: "Hard",
    usersTried: 2980,
    acceptanceRate: "38%",
    type: "assignment",
    duration: "45 minutes",
    dsaCategory: "Tries",
    completed: false
  },
  {
    id: 13,
    title: "LRU Cache",
    tags: ["Hash Table", "Linked List", "Design"],
    companies: ["Amazon", "Microsoft", "Facebook"],
    difficulty: "Medium",
    usersTried: 7832,
    acceptanceRate: "54%",
    type: "question",
    duration: "30 minutes",
    dsaCategory: "Design",
    completed: true
  },
  {
    id: 14,
    title: "Longest Increasing Subsequence",
    tags: ["Binary Search", "Dynamic Programming"],
    companies: ["Microsoft", "Amazon", "Google"],
    difficulty: "Medium",
    usersTried: 6278,
    acceptanceRate: "49%",
    type: "assignment",
    duration: "25 minutes",
    dsaCategory: "Dynamic Programming",
    completed: false
  },
  {
    id: 15,
    title: "Alien Dictionary",
    tags: ["Graph", "Topological Sort"],
    companies: ["Facebook", "Amazon", "Airbnb"],
    difficulty: "Hard",
    usersTried: 3254,
    acceptanceRate: "35%",
    type: "question",
    duration: "40 minutes",
    dsaCategory: "Graphs",
    completed: false
  }
];

export const userProgress = {
  easy: {
    completed: 3,
    total: 4
  },
  medium: {
    completed: 2,
    total: 7
  },
  hard: {
    completed: 0,
    total: 4
  }
};

export const dsaCategories = [
  "Arrays & Hashing",
  "Strings",
  "Stack",
  "Linked Lists",
  "Dynamic Programming",
  "Trees",
  "Graphs",
  "Heap/Priority Queue",
  "Two Pointers",
  "Tries",
  "Design"
];
