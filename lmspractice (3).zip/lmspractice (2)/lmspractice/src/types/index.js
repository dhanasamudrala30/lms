const Problem = {
    id: 1,                    // number
    title: "Example Problem",  // string
    tags: ["array", "hashing"],// array of strings
    companies: ["Google", "Amazon"], // array of strings
    difficulty: "Easy",        // 'Easy' | 'Medium' | 'Hard'
    usersTried: 1000,          // number
    acceptanceRate: "75%",     // string
    type: "question",          // 'question' | 'assignment'
    duration: "30 min",        // string
    dsaCategory: "Arrays",     // string
    completed: false,          // optional boolean
  };
  
  // User Progress Data Structure
  const UserProgress = {
    easy: {
      completed: 10, // number
      total: 20,     // number
    },
    medium: {
      completed: 5,  // number
      total: 10,     // number
    },
    hard: {
      completed: 2,  // number
      total: 5,      // number
    },
  };
  