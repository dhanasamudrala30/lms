import React, { useState } from 'react';
import { problems, userProgress } from '../data/problemsData';
import ProblemTable from '../components/ProblemTable';
import ProgressGraph from '../components/ProgressGraph';
import DifficultyFilter from '../components/DifficultyFilter';

const PracticeArea = () => {
  const [selectedDifficulty, setSelectedDifficulty] = useState('All');
  const [selectedCategory, setSelectedCategory] = useState('All');

  const categories = Array.from(new Set(problems.map(p => p.dsaCategory)));

  const filteredProblems = problems.filter(problem => {
    const matchesDifficulty = selectedDifficulty === 'All' || problem.difficulty === selectedDifficulty;
    const matchesCategory = selectedCategory === 'All' || problem.dsaCategory === selectedCategory;
    return matchesDifficulty && matchesCategory;
  });

  return (
    <div className="min-h-screen bg-white">
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Left Sidebar */}
          <div className="lg:col-span-1 space-y-6">
            {/* Coding Challenges Header */}
            <div className="bg-white rounded-lg p-6 shadow-sm border">
              <h1 className="text-xl font-bold text-gray-800 mb-2">Coding Challenges</h1>
              <p className="text-sm text-gray-600 mb-4">
                Practice DSA problems to improve your coding skills. Track your progress and challenge yourself with problems of varying difficulty.
              </p>
              <DifficultyFilter 
                selectedDifficulty={selectedDifficulty} 
                setSelectedDifficulty={setSelectedDifficulty} 
              />
            </div>

            {/* Progress Section */}
            <div className="bg-white rounded-lg p-6 shadow-sm border">
              <h2 className="text-lg font-semibold text-gray-800 mb-4">Your Progress</h2>
              <ProgressGraph userProgress={userProgress} />
            </div>

            {/* DSA Categories */}
            <div className="bg-white rounded-lg p-6 shadow-sm border">
              <h2 className="text-lg font-semibold text-gray-800 mb-4">DSA Categories</h2>
              <div className="space-y-2">
                <div
                  onClick={() => setSelectedCategory('All')}
                  className={`cursor-pointer px-3 py-2 rounded-lg flex justify-between items-center ${
                    selectedCategory === 'All'
                      ? 'bg-blue-50 text-blue-600'
                      : 'hover:bg-gray-50 text-gray-700'
                  }`}
                >
                  <span>All Topics</span>
                  <span className="text-sm bg-blue-100 text-blue-600 px-2 py-0.5 rounded-full">
                    {problems.length}
                  </span>
                </div>
                {categories.map((category) => {
                  const count = problems.filter(p => p.dsaCategory === category).length;
                  return (
                    <div
                      key={category}
                      onClick={() => setSelectedCategory(category)}
                      className={`cursor-pointer px-3 py-2 rounded-lg flex justify-between items-center ${
                        selectedCategory === category
                          ? 'bg-blue-50 text-blue-600'
                          : 'hover:bg-gray-50 text-gray-700'
                      }`}
                    >
                      <span>{category}</span>
                      <span className="text-sm bg-blue-100 text-blue-600 px-2 py-0.5 rounded-full">
                        {count}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Right Content - Problem Table */}
          <div className="lg:col-span-3">
            <div className="bg-white rounded-lg shadow-sm border">
              <div className="p-4 border-b flex justify-between items-center">
                <h2 className="text-lg font-semibold text-gray-800">Problems</h2>
                <span className="text-sm text-gray-600">
                  Showing {filteredProblems.length} problems
                </span>
              </div>
              <ProblemTable 
                problems={filteredProblems} 
                selectedDifficulty={selectedDifficulty} 
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PracticeArea;
